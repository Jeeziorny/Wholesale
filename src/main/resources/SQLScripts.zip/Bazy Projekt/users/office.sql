CREATE USER 'office'@'localhost' IDENTIFIED BY '1234';

GRANT SELECT
	ON wholesale.chipboard
    TO 'office'@'localhost';
    
GRANT SELECT
	ON wholesale.chipboard_size
    TO 'office'@'localhost';
    
GRANT SELECT, INSERT, UPDATE
	ON wholesale.customers
    TO 'office'@'localhost';
    
GRANT SELECT
	ON wholesale.order_item
    TO 'office'@'localhost';
    
GRANT SELECT, INSERT
	ON wholesale.orders
    TO 'office'@'localhost';
    
GRANT SELECT
	ON wholesale.warehouse
    TO 'office'@'localhost';
    
flush PRIVILEGES;