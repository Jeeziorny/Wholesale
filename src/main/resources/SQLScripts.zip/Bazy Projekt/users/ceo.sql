CREATE USER 'ceo'@'localhost' IDENTIFIED BY '1234';

GRANT SELECT, INSERT, UPDATE, DELETE
	ON wholesale.chipboard
    TO 'ceo'@'localhost';
    
GRANT SELECT, INSERT, UPDATE, DELETE
	ON wholesale.chipboard_size
    TO 'ceo'@'localhost';
    
GRANT SELECT, INSERT, UPDATE
	ON wholesale.customers
    TO 'ceo'@'localhost';
    
GRANT SELECT
	ON wholesale.income
    TO 'ceo'@'localhost';
    
GRANT SELECT
	ON wholesale.order_item
    TO 'ceo'@'localhost';
    
GRANT SELECT, INSERT, DELETE
	ON wholesale.orders
    TO 'ceo'@'localhost';
    
GRANT SELECT, INSERT, UPDATE
	ON wholesale.warehouse
    TO 'ceo'@'localhost';
    
flush PRIVILEGES;