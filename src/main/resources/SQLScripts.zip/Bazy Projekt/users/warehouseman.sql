CREATE USER 'warehouseman'@'localhost' IDENTIFIED BY '1234';

GRANT SELECT
	ON wholesale.chipboard
    TO 'warehouseman'@'localhost';
    
GRANT SELECT
	ON wholesale.chipboard_size
    TO 'warehouseman'@'localhost';
    
GRANT SELECT, UPDATE
	ON wholesale.order_item
    TO 'warehouseman'@'localhost';
    
GRANT SELECT, UPDATE
	ON wholesale.orders
    TO 'office'@'localhost';
    
GRANT SELECT, UPDATE
	ON wholesale.warehouse
    TO 'office'@'localhost';
    
flush PRIVILEGES;