DROP DATABASE IF EXISTS `wholesale`;

CREATE DATABASE `wholesale`;

use wholesale;

CREATE TABLE chipboard_size (
	id 			INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    length 		INT NOT NULL COMMENT 'unit: milimeters',
    width		INT NOT NULL COMMENT 'unit: milimeters',
    thicknes 	INT NOT NULL COMMENT 'unit: milimeters'
);

CREATE TABLE chipboard (
	id		INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sizeId	INT NOT NULL,
    cost	DOUBLE NOT NULL,
    
    FOREIGN KEY (sizeId) REFERENCES chipboard_size(id)
);

CREATE TABLE warehouse (
	chipboardId	INT NOT NULL,
    quantity	INT,
    
    FOREIGN KEY (chipboardId) REFERENCES chipboard(id)
);

CREATE TABLE customers ( 
	id			INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    NIP			INT NOT NULL UNIQUE KEY,
    name		VARCHAR(45),
    discount	DOUBLE NOT NULL
);

CREATE TABLE orders ( /* USUNALEM CHARGE */
	id				INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    customerId		INT NOT NULL,
    paymentStatus	ENUM('DONE', 'PENDING'),
    orderStatus		ENUM('SUSPENDED', 'PENDING', 'DONE', 'LACK OF MATERIALS', 'CONSTRUCTION'),
    
    FOREIGN KEY (customerId) REFERENCES customers(id)
);

CREATE TABLE order_item (
	chipboardId		INT NOT NULL,
    quantity		INT,
    orderId			INT NOT NULL,
    
    FOREIGN KEY (chipboardId) REFERENCES chipboard(Id),
    FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
);

/*frequent searches*/
CREATE INDEX idx ON order_item (orderId);

CREATE TABLE income (
	operationId		INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    operation_value	DOUBLE,
    orderId			INT NOT NULL,
    operation_date	DATETIME,
    
    FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
)
    

	

    
    