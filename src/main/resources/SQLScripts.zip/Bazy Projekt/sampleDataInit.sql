INSERT INTO wholesale.chipboard_size (length, width, thicknes)
VALUES 	(2000, 3000, 20),
		(2000, 3000, 30),
        (2000, 3000, 40);
        
CALL fill_chipboard_table();

INSERT INTO wholesale.customers (NIP, name, discount)
VALUES 	(222222221, 'TOMPOL', 0.1),
		(222222231, 'KAMPOL', 0),
        (222222211, 'PRZEMPOL', 0),
        (222222111, 'KUBAPOL', 0.3),
        (222221111, 'RAFPOL', 0.6),
        (222211111, 'BARTPOL', 0),
        (222111111, 'PAWPOL', 0.25),
        (221111111, 'MATPOL', 0),
        (211111111, 'PIOTRPOL', 0),
        (111111111, 'MICHPOL', 0.5);

CALL fill_orders_and_orderItem();

INSERT INTO income (operation_value, orderId, operation_date)
SELECT SUM(quantity*cost), id, NOW()
FROM (
	SELECT item.quantity, C.cost, O.id
	FROM orders O
	INNER JOIN order_item item
		ON O.id = item.orderId
	INNER JOIN chipboard C
		ON item.chipboardId = C.id
	WHERE O.paymentStatus = 'DONE') AS temp
GROUP BY id;

INSERT INTO warehouse (chipboardId, quantity)
SELECT id, FLOOR(RAND()*30 + 20) AS quantity
FROM chipboard;
