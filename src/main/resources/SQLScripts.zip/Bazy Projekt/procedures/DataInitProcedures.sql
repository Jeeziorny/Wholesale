DROP PROCEDURE IF EXISTS fill_chipboard_table;
DROP PROCEDURE IF EXISTS fill_orders_and_orderItem;
DROP PROCEDURE IF EXISTS fill_orderItem;

DELIMITER $$
CREATE PROCEDURE fill_chipboard_table()
BEGIN
DECLARE bound INT UNSIGNED DEFAULT 100;
DECLARE iterator INT UNSIGNED DEFAULT 0;

WHILE iterator < bound do
	IF (iterator < 33) THEN
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (1, FLOOR(RAND()*2000 + 1000));
	ELSEIF (iterator < 66) THEN
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (2, FLOOR(RAND()*2000 + 1000));
	ELSE 
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (3, FLOOR(RAND()*2000 + 1000));
	END IF;
    SET iterator = iterator + 1;
END WHILE;
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE fill_orderItem(IN IDOrder INT)
BEGIN
DECLARE bound INT UNSIGNED DEFAULT FLOOR(RAND()*5+3);
DECLARE iterator INT UNSIGNED DEFAULT 0;
	WHILE iterator < bound DO
		INSERT INTO wholesale.order_item (chipboardId, quantity, orderId)
        VALUE (FLOOR(RAND()*100)+1, FLOOR(RAND()*5+3), IDOrder);
        SET iterator = iterator + 1;
    END WHILE;
END $$;
DELIMITER;

DELIMITER $$
CREATE PROCEDURE fill_orders_and_orderItem()
BEGIN
DECLARE bound INT UNSIGNED DEFAULT 20;
DECLARE iterator INT UNSIGNED DEFAULT 0;
DECLARE paymentStatus VARCHAR(20) DEFAULT 'DONE';
DECLARE orderStatus VARCHAR(20) DEFAULT 'DONE';
	WHILE iterator < bound DO 
		IF (iterator % 4 = 0) THEN
			SET paymentStatus = 'DONE';
            SET orderStatus = 'DONE';
		ELSEIF (iterator % 4 = 1) THEN
			SET paymentStatus = 'DONE';
            SET orderStatus = 'PENDING';
        ELSE
			SET paymentStatus = 'PENDING';
            SET orderStatus = 'SUSPENDED';
        END IF;
        
	INSERT INTO wholesale.orders (customerId, paymentStatus, orderStatus)
	VALUE (FLOOR(RAND()*10)+1, paymentStatus, orderStatus);
    SET iterator = iterator + 1;
    CALL fill_orderItem(iterator);
END WHILE;
END $$
DELIMITER ;
