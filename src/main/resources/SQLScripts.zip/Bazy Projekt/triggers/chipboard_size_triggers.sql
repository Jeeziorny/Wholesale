use wholesale;

DELIMITER $$
CREATE TRIGGER sizes_before_insert
BEFORE INSERT ON chipboard_size
FOR EACH ROW
BEGIN
	IF (new.length < 5 OR new.width < 5 OR new.thicknes < 5
		OR
        new.length > 4000 OR new.width > 4000 OR new.thicknes > 50) THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'InvalidChipboardSizeException';
	END IF;
END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER sizes_before_update
BEFORE UPDATE ON chipboard_size
FOR EACH ROW
BEGIN
	IF (new.length < 5 OR new.width < 5 OR new.thicknes < 5
		OR
        new.length > 4000 OR new.width > 4000 OR new.thicknes > 50) THEN
		SIGNAL SQLSTATE '45001'
        SET MESSAGE_TEXT = 'InvalidChipboardSizeException';
	END IF;
END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER sizes_before_delete
BEFORE DELETE ON chipboard_size
FOR EACH ROW
BEGIN
	IF (SELECT EXISTS (SELECT *
					   FROM chipboard
                       WHERE sizeId = old.id)) THEN
		SIGNAL SQLSTATE '45002'
        SET MESSAGE_TEXT = 'UsedInOtherDataException';
	END IF;
END $$
DELIMITER ;
        
        
        
        
        
        