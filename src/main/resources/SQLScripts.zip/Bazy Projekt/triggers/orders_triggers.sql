DELIMITER $$
CREATE TRIGGER orders_after_update
BEFORE UPDATE ON orders
FOR EACH ROW
BEGIN
	IF (paymentStatus.old = 'PENDING' 
			AND paymentStatus.new = 'DONE') THEN
		INSERT INTO income (operation_value, orderId, operation_date)
        VALUE (charge.old, id.old, CURDATE());
	END IF;
END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER orders_before_delete
BEFORE DELETE ON orders
FOR EACH ROW
BEGIN
	IF (orderStatus.old = 'PENDING' OR orderStatus.old = 'DONE'
			OR orderStatus.old = 'CONSTRUCTION') THEN
		SIGNAL SQLSTATE '45003'
        SET MESSAGE_TEXT = 'OrderUnderConstructionException';
	END IF;
END $$
DELIMITER ;