create trigger orders_before_delete
  before DELETE
  on orders
  for each row
  BEGIN
	IF (orderStatus.old <> 'SUSPENDED') THEN
		SIGNAL SQLSTATE '45003'
        SET MESSAGE_TEXT = 'OrderUnderConstructionException';
	END IF;
END;

