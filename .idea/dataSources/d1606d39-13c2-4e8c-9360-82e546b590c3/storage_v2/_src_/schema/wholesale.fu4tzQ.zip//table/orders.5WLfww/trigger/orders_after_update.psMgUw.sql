create trigger orders_after_update
  before UPDATE
  on orders
  for each row
  BEGIN
	IF (paymentStatus.old = 'PENDING' 
			AND paymentStatus.new = 'DONE') THEN
		INSERT INTO income (operation_value, orderId, operation_date)
        VALUE (charge.old, id.old, CURDATE());
	END IF;
END;

