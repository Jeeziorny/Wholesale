create procedure fill_orderItem(IN IDOrder int)
  BEGIN
DECLARE bound INT UNSIGNED DEFAULT FLOOR(RAND()*5+3);
DECLARE iterator INT UNSIGNED DEFAULT 0;
	WHILE iterator < bound DO
		INSERT INTO wholesale.order_item (chipboardId, quantity, orderId)
        VALUE (FLOOR(RAND()*100)+1, FLOOR(RAND()*5+3), IDOrder);
        SET iterator = iterator + 1;
    END WHILE;
END;

