create procedure fill_orders_and_orderItem()
  BEGIN
DECLARE bound INT UNSIGNED DEFAULT 20;
DECLARE iterator INT UNSIGNED DEFAULT 0;
DECLARE paymentStatus VARCHAR(20) DEFAULT 'DONE';
DECLARE orderStatus VARCHAR(20) DEFAULT 'DONE';
	WHILE iterator < bound DO 
		IF (iterator % 4 = 0) THEN
			SET paymentStatus = 'DONE';
            SET orderStatus = 'DONE';
		ELSEIF (iterator % 4 = 1) THEN
			SET paymentStatus = 'DONE';
            SET orderStatus = 'PENDING';
        ELSE
			SET paymentStatus = 'PENDING';
            SET orderStatus = 'SUSPENDED';
        END IF;
        
	INSERT INTO wholesale.orders (customerId, paymentStatus, orderStatus)
	VALUE (FLOOR(RAND()*10)+1, paymentStatus, orderStatus);
    SET iterator = iterator + 1;
    CALL fill_orderItem(iterator);
END WHILE;
END;

