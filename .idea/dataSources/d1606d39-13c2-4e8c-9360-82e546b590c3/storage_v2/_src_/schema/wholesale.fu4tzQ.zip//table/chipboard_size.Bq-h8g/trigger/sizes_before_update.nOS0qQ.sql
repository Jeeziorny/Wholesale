create trigger sizes_before_update
  before UPDATE
  on chipboard_size
  for each row
  BEGIN
	IF (new.length < 5 OR new.width < 5 OR new.thicknes < 5
		OR
        new.length > 4000 OR new.width > 4000 OR new.thicknes > 50) THEN
		SIGNAL SQLSTATE '45001'
        SET MESSAGE_TEXT = 'InvalidChipboardSizeException';
	END IF;
END;

