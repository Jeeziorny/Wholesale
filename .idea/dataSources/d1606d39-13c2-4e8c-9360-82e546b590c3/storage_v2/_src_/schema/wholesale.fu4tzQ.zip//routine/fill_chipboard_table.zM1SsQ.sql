create procedure fill_chipboard_table()
  BEGIN
DECLARE bound INT UNSIGNED DEFAULT 100;
DECLARE iterator INT UNSIGNED DEFAULT 0;

WHILE iterator < bound do
	IF (iterator < 33) THEN
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (1, FLOOR(RAND()*2000 + 1000));
	ELSEIF (iterator < 66) THEN
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (2, FLOOR(RAND()*2000 + 1000));
	ELSE 
		INSERT INTO wholesale.chipboard (sizeId, cost)
        VALUE (3, FLOOR(RAND()*2000 + 1000));
	END IF;
    SET iterator = iterator + 1;
END WHILE;
END;

