create trigger sizes_before_delete
  before DELETE
  on chipboard_size
  for each row
  BEGIN
	IF (SELECT EXISTS (SELECT *
					   FROM chipboard
                       WHERE sizeId = old.id)) THEN
		SIGNAL SQLSTATE '45002'
        SET MESSAGE_TEXT = 'UsedInOtherDataException';
	END IF;
END;

